import { pipeline, env } from "https://cdn.jsdelivr.net/npm/@huggingface/transformers@3.7.2";

env.allowLocalModels = false;
env.useBrowserCache = true;

const MODEL = "Xenova/Qwen2.5-0.5B-Instruct";
let generator = null;
let loading = false;
let messages = [];
let chats = JSON.parse(localStorage.getItem("govaki_chats") || "[]");
let settings = JSON.parse(localStorage.getItem("govaki_settings") || '{"maxTokens":220,"style":"normal"}');

const $ = id => document.getElementById(id);
const chat = $("chat"), welcome = $("welcome"), input = $("input"), send = $("send");

function saveChats(){ localStorage.setItem("govaki_chats", JSON.stringify(chats.slice(-20))); }
function renderHistory(){
  const h=$("history"); h.innerHTML="";
  chats.slice().reverse().forEach((c,i)=>{
    const b=document.createElement("button"); b.textContent=c.title||"Neuer Chat";
    b.onclick=()=>loadChat(chats.length-1-i); h.appendChild(b);
  });
}
function addMessage(role,text){
  welcome.style.display="none";
  const row=document.createElement("div"); row.className="message "+role;
  const bubble=document.createElement("div"); bubble.className="bubble"; bubble.textContent=text;
  row.appendChild(bubble); chat.appendChild(row); chat.scrollTop=chat.scrollHeight; return bubble;
}
function newChat(){
  messages=[]; chat.innerHTML=""; chat.appendChild(welcome); welcome.style.display="";
  $("sidebar").classList.remove("open"); input.value=""; input.focus();
}
function loadChat(index){
  const c=chats[index]; if(!c)return;
  messages=c.messages||[]; chat.innerHTML=""; chat.appendChild(welcome); welcome.style.display="none";
  messages.forEach(m=>addMessage(m.role,m.content)); $("sidebar").classList.remove("open");
}
async function getGenerator(){
  if(generator) return generator;
  if(loading) { while(loading) await new Promise(r=>setTimeout(r,100)); return generator; }
  loading=true; send.disabled=true; send.textContent="…";
  try{
    generator=await pipeline("text-generation",MODEL,{device:"webgpu",dtype:"q4"});
  }catch(e){
    generator=await pipeline("text-generation",MODEL,{dtype:"q4"});
  }
  loading=false; send.disabled=false; send.textContent="➤";
  return generator;
}
function buildPrompt(){
  let style=settings.style==="short"?"Antworte kurz und direkt.":settings.style==="school"?"Erkläre einfach und passend für einen Schüler.":"Antworte hilfreich, freundlich und klar.";
  let prompt=`<|im_start|>system\nDu bist GovaKI, ein freundlicher KI-Assistent. ${style}<|im_end|>\n`;
  for(const m of messages.slice(-8)) prompt+=`<|im_start|>${m.role==="user"?"user":"assistant"}\n${m.content}<|im_end|>\n`;
  prompt+="<|im_start|>assistant\n";
  return prompt;
}
async function sendMessage(text){
  text=text.trim(); if(!text||loading)return;
  input.value=""; input.style.height="auto";
  addMessage("user",text); messages.push({role:"user",content:text});
  const bubble=addMessage("assistant","GovaKI wird geladen …");
  try{
    const gen=await getGenerator();
    bubble.textContent="GovaKI denkt …";
    const out=await gen(buildPrompt(),{max_new_tokens:Number(settings.maxTokens),do_sample:true,temperature:.7,return_full_text:false});
    let answer=out?.[0]?.generated_text ?? "Ich konnte gerade keine Antwort erzeugen.";
    if(typeof answer!=="string") answer=JSON.stringify(answer);
    answer=answer.replace(/<\|im_end\|>.*/s,"").trim();
    bubble.textContent=answer||"Keine Antwort.";
    messages.push({role:"assistant",content:bubble.textContent});
    chats.push({title:text.slice(0,42),messages:[...messages]}); saveChats(); renderHistory();
  }catch(e){
    bubble.textContent="Fehler beim Laden der KI. Bitte lade die Seite neu und versuche es noch einmal.";
    console.error(e);
  }
}
send.onclick=()=>sendMessage(input.value);
input.addEventListener("keydown",e=>{if(e.key==="Enter"&&!e.shiftKey){e.preventDefault();send.click()}});
input.addEventListener("input",()=>{input.style.height="auto";input.style.height=Math.min(input.scrollHeight,150)+"px"});
document.querySelectorAll("[data-prompt]").forEach(b=>b.onclick=()=>{input.value=b.dataset.prompt;send.click()});
$("newChat").onclick=newChat;
$("clearBtn").onclick=newChat;
$("menuBtn").onclick=()=>$("sidebar").classList.toggle("open");
$("settingsBtn").onclick=()=>{$("settingsModal").classList.remove("hidden");$("maxTokens").value=settings.maxTokens;$("tokenValue").textContent=settings.maxTokens;$("style").value=settings.style};
$("closeSettings").onclick=()=>$("settingsModal").classList.add("hidden");
$("saveSettings").onclick=()=>{settings={maxTokens:$("maxTokens").value,style:$("style").value};localStorage.setItem("govaki_settings",JSON.stringify(settings));$("settingsModal").classList.add("hidden")};
$("maxTokens").oninput=e=>$("tokenValue").textContent=e.target.value;
renderHistory();
