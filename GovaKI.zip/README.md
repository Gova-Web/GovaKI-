# GovaKI

Eine moderne ChatGPT-ähnliche KI-Webseite, die direkt im Browser läuft.

## Start
Am einfachsten über GitHub Pages, Cloudflare Pages oder einen anderen HTTPS-Webhost veröffentlichen.

Wichtig: Das KI-Modell wird beim ersten Start aus dem Internet geladen. Danach kann der Browser es zwischenspeichern. Auf einem schwächeren Handy kann die KI langsam sein.

## Dateien
- index.html – Webseite
- style.css – Design
- app.js – KI und Chat
- manifest.json – PWA
- icon.svg – GovaKI Icon

## Hinweis
GovaKI nutzt Transformers.js und das Modell Xenova/Qwen2.5-0.5B-Instruct. Die KI läuft im Browser; es ist kein eigener API-Key nötig.
